### Fashion store website template

![Fashion store website template](fashion-store-website.gif)

Fashion store HTML Template is a clean and single page design – suitable for selling clothing, fashion, high fashion, men fashion, women fashion, accessories, digital, kids, watches, jewelry, shoes, kids, furniture, sports, tools….. It has a fully responsive width adjusts automatically to any screen size or resolution.


### Features
- [x] HTML5 & CSS3
- [x] No framework
- [x] Responsive Template
- [x] Free icons used
- [x] Pixel Perfect
- [x] Clean & Unique Design
- [x] Easy to customize
- [x] Retina Ready
- [x] Unlimited Colors
- [x] Boxed or Wide layout



.
.
.
.

[![Nihory - Portfolio site template live demo](https://i.ibb.co/vwN8cgW/live-demo.png)](https://fashion-store-opensource.netlify.app/)

.
.
.


[![Atul - Buy Me A Coffee](https://i.ibb.co/7rR9S4L/buy-me-a-coffee.png)](https://www.buymeacoffee.com/atulcodex)